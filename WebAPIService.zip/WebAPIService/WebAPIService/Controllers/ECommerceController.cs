﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPIService.Models;
using WebAPIService.Models.VM;

namespace WebAPIService.Controllers
{
    [RoutePrefix("Api/Ecom")]
    public class ECommerceController : ApiController
    {
      
        EmployeeEntities db = new EmployeeEntities();


        [Route("GetCategory")]
        [HttpGet]
       public IEnumerable<Category> GetCategory()
        {
            return db.Category.ToList();
        }

        [Route("GetCategoryById")]
        [HttpGet]
        public object GetCategoryById(int Id)
        {
            return db.Category.Where(s => s.CatId == Id).ToList<Category>().FirstOrDefault();
        }

        [Route("CategoryPost")]
        [HttpPost]
        public object CategoryPost (CategoryVM cat)
        {
            try
            {
                Category obj = new Category();
                if(cat.CatId == 0)
                {
                    obj.CatName = cat.CatName;
                    obj.CatType = cat.CatType;
                    obj.CatImage = cat.CatImage;
                    db.Category.Add(obj);
                    db.SaveChanges();
                    return new ResultVM
                    { status = "Success", message = "Successfully Save" };
                }
            }
            catch(Exception ex)
            {
                throw;
            }
            return new ResultVM
            { status = "Error", message = "Invalid Data" };
        }
       

    }
}
