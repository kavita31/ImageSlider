import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Appclass } from './appclass';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppserviceService {
   

url : string ='http://localhost:62439/Api/Ecom'
  constructor(private httpservice : HttpClient) { }

 getcategory(): Observable <Appclass[]>  
{return this.httpservice.get<Appclass[]>(this.url + '/GetCategory'); }

Getcategorybyid (CatId : string ): Observable<Appclass>
{
  return this.httpservice.get<Appclass>
  (this.url + '/GetCategoryById?Id='+CatId);
}
}
