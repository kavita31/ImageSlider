import { Component, OnInit } from '@angular/core';
import {NgbCarouselConfig} from '@ng-bootstrap/ng-bootstrap'
import { AppserviceService } from './appservice.service';
import { Observable } from 'rxjs';
import { Appclass } from './appclass';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(config : NgbCarouselConfig , private httpservice : AppserviceService){
  //config.interval= 2000;
  config.wrap=true;
  config.keyboard = false;
  config.pauseOnHover = false;
  }

  getcategories : Observable<Appclass[]>;
 
  Getallcategory ()
  {
      this.getcategories = this.httpservice.getcategory();
      
  }

  ngOnInit ()
  {
    this.Getallcategory();
  }
  
}
