export class Appclass {
    CatId : string;
    CatName : string ;
    CatType : string;
    CatImage : string;
}
